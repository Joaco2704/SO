
#!/bin/bash
if [ $EUID -eq 0 ]; then
	echo "Ejecutando como root"
	echo -n "Menu
	1.Fecha.
	2.Usuarios conectados.
	3.Información de CPU.
	4.Ubicación actual.
	5.Información de las particiones.
	6.Cantidad de procesos en ejecución (de manera estática, no usando top).
	7.Comprimir arcivo.
	8.Descomprimir.
	9.Conexion ssh.
	10.Bloqueo de IP" 
	read rta
	conexion(){
		echo "Ingrese el nombre de usuario de la computadora a conectar: "
		read nombre
		echo "Ingrese la IP: "
		read ip
		ssh $nombre@$ip
	}
	bloqueo(){
		echo  "Ingrese la ip de la compu 2: "
		read compu2
		echo "Ingrese la ip de la compu 1: "
		read compu1
		sudo iptables -A INPUT -p icmp -s $compu2 -d $compu1 -j DROP 
	}
	comprimir(){
		echo "Ingrese el nombre del archivo a comprimir: "
		read archivo
		echo "Ingrese el nombre de la carpeta: "
		read carpeta
		sudo tar -cf $archivo.tar $carpeta  
	}
	
	descomprimir(){
		echo "Ingrese el nombre del directorio a crear:"
		read directorio
		echo "Ingrese la ruta donde se encuentra el archivo a descomprimir:"
		read des 
		mkdir $directorio
		cd $directorio
		sudo tar -xvf $des
		

	}
	case $rta in
		1)
			echo "La fecha es:" 
			date
			date >> informacion.txt;;
		2)
			echo "El usuario conectado es:"
			who 
			who >> informacion.txt;;
		3)
			echo "Iformación del CPU"
			lscpu
			lscpu >> informacion.txt;;
		4)
			echo "La ubicacó actual es:"
			who;date
			who;date >> iformacion.txt;;
		5)
			echo "Paticiones:"
			df -h
			df -h >> informacion.txt;;
		6)
			echo "Procesos en ejecución:"
			ps -ef
			ps -ef >> informacion.txt
			echo "Ingrese el id del proceso que desea matar:"
			read respuesta 
			kill $respuesta;;
		7)
    			 comprimir;;
		8)
			 descomprimir;;
		9) 	conexion;;
		10) 	bloqueo
	esac
	echo $rta
else 
 echo "Este script requiere privilegios de root para ejecutarse."
fi
# FIN DEL SCRIPT

